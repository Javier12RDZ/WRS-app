
const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cron = require('node-cron');

const app = express();
const PORT = 3000;
const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const JWT_SECRET = 'your-super-secret-key'; // TODO: Debería estar en una variable de entorno

// --- Middleware ---
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) return res.sendStatus(401); // No hay token

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403); // Token inválido
        req.user = user;
        next();
    });
};

const isAdmin = (req, res, next) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Acceso denegado. Se requiere rol de administrador.' });
    }
    next();
};

// --- Rutas de Autenticación ---

app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ message: 'Nombre de usuario y contraseña son requeridos.' });
    }

    try {
        const usersData = await fs.readFile(USERS_FILE, 'utf-8');
        const users = JSON.parse(usersData);
        const user = users.find(u => u.username === username);

        if (!user) {
            return res.status(400).json({ message: 'Usuario o contraseña incorrectos.' });
        }

        if (await bcrypt.compare(password, user.password)) {
            // Contraseña correcta, crear JWT
            const accessToken = jwt.sign({ username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '1h' });
            res.json({ accessToken: accessToken, user: { username: user.username, role: user.role } });
        } else {
            res.status(400).json({ message: 'Usuario o contraseña incorrectos.' });
        }
    } catch (error) {
        console.error('Error en el login:', error);
        res.status(500).json({ message: 'Error interno del servidor.' });
    }
});


// --- API Endpoints para WRS (Proyectos) ---

const countItems = (data) => {
    if (!data) return 0;
    let count = 0;
    if (data.assembly) count += data.assembly.length;
    if (data.electrical) count += data.electrical.length;
    if (data.engineering) count += data.engineering.length;
    if (data.support) count += data.support.length;
    if (data.quality) count += data.quality.length;
    return count;
};

app.get('/api/wrs/:id', async (req, res) => {
    const wrsId = req.params.id;
    const filePath = path.join(DATA_DIR, `${wrsId}.json`);

    try {
        const data = await fs.readFile(filePath, 'utf-8');
        res.json(JSON.parse(data));
    } catch (error) {
        if (error.code === 'ENOENT') {
            // Si el proyecto no existe, se crea uno nuevo con versión 0
            res.json({
                wrs: wrsId,
                version: 0,
                assembly: [],
                electrical: [],
                engineering: [],
                support: [],
                quality: [],
            });
        } else {
            console.error('Error al leer el archivo del proyecto:', error);
            res.status(500).json({ message: 'Error interno al leer el proyecto' });
        }
    }
});

app.post('/api/wrs/:id', async (req, res) => {
    const wrsId = req.params.id;
    const filePath = path.join(DATA_DIR, `${wrsId}.json`);
    const incomingData = req.body;

    try {
        let existingData = {};
        let currentVersion = 0;
        try {
            const existingFileContent = await fs.readFile(filePath, 'utf-8');
            existingData = JSON.parse(existingFileContent);
            currentVersion = existingData.version || 0;
        } catch (readError) {
            if (readError.code !== 'ENOENT') throw readError;
        }

        const isDeletion = countItems(incomingData) < countItems(existingData);

        if (isDeletion) {
            const authHeader = req.headers['authorization'];
            const token = authHeader && authHeader.split(' ')[1];

            if (token == null) {
                return res.status(401).json({ message: 'Se requiere autenticación de administrador para eliminar.' });
            }

            let user;
            try {
                user = jwt.verify(token, JWT_SECRET);
            } catch (err) {
                return res.status(403).json({ message: 'Token inválido o expirado.' });
            }

            if (user.role !== 'admin') {
                return res.status(403).json({ message: 'Se requieren permisos de administrador para eliminar.' });
            }
        }

        if (incomingData.version !== currentVersion) {
            return res.status(409).json({ 
                message: 'Conflicto de versiones. Alguien más ha guardado cambios en este proyecto. Por favor, recarga la página.' 
            });
        }

        incomingData.version = currentVersion + 1;

        await fs.mkdir(DATA_DIR, { recursive: true });
        await fs.writeFile(filePath, JSON.stringify(incomingData, null, 2), 'utf-8');
        res.status(200).json({ message: 'Proyecto guardado con éxito', newVersion: incomingData.version });

    } catch (error) {
        console.error(`Error al guardar el proyecto ${wrsId}:`, error);
        res.status(500).json({ message: 'Error interno al guardar el proyecto' });
    }
});

app.delete('/api/wrs/:id', authenticateToken, isAdmin, async (req, res) => {
    const wrsId = req.params.id;
    const filePath = path.join(DATA_DIR, `${wrsId}.json`);

    try {
        await fs.unlink(filePath);
        res.status(200).json({ message: 'Proyecto eliminado con éxito.' });
    } catch (error) {
        if (error.code === 'ENOENT') {
            return res.status(404).json({ message: 'Proyecto no encontrado.' });
        }
        console.error(`Error al eliminar el proyecto ${wrsId}:`, error);
        res.status(500).json({ message: 'Error interno al eliminar el proyecto.' });
    }
});

// --- Technician Report Endpoint ---
app.get('/api/report/technician/:name', authenticateToken, async (req, res) => {
    const techName = req.params.name.toLowerCase();
    let reportData = [];

    try {
        const files = await fs.readdir(DATA_DIR);
        const projectFiles = files.filter(file => file.endsWith('.json') && file !== 'users.json');

        for (const file of projectFiles) {
            const filePath = path.join(DATA_DIR, file);
            const fileContent = await fs.readFile(filePath, 'utf-8');
            const projectData = JSON.parse(fileContent);

            const checkArray = (arr, type) => {
                if (!arr || !Array.isArray(arr)) return;
                arr.forEach(item => {
                    if (item.tecnico && item.tecnico.toLowerCase().includes(techName)) {
                        const estimatedTime = item.estimatedTime || 0;
                        const accumulatedTime = item.accumulatedTime || 0;
                        const remainingTime = estimatedTime - accumulatedTime;
                        const savingsPercentage = estimatedTime > 0 ? (remainingTime / estimatedTime) * 100 : 0;

                        reportData.push({
                            wrs: projectData.wrs,
                            type: type,
                            partNumber: item.number,
                            quantity: item.quantity,
                            estimatedTime: estimatedTime,
                            accumulatedTime: accumulatedTime,
                            remainingTime: remainingTime,
                            savingsPercentage: savingsPercentage,
                            comment: item.comment || '',
                            updatedAt: item.updatedAt
                        });
                    }
                });
            };

            checkArray(projectData.assembly, 'Ensamble');
            checkArray(projectData.electrical, 'Prueba Eléctrica');
        }

        reportData.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
        res.json(reportData);

    } catch (error) {
        console.error('Error generating technician report:', error);
        res.status(500).json({ message: 'Error interno al generar el reporte.' });
    }
});


// --- API Endpoints para Gestión de Usuarios (Solo Admins) ---

app.get('/api/users', authenticateToken, isAdmin, async (req, res) => {
    try {
        const usersData = await fs.readFile(USERS_FILE, 'utf-8');
        const users = JSON.parse(usersData);
        // No enviar las contraseñas al cliente
        const usersWithoutPasswords = users.map(({ password, ...user }) => user);
        res.json(usersWithoutPasswords);
    } catch (error) {
        console.error('Error al leer el archivo de usuarios:', error);
        res.status(500).json({ message: 'Error interno del servidor.' });
    }
});

app.post('/api/users', authenticateToken, isAdmin, async (req, res) => {
    const { username, password, role } = req.body;
    if (!username || !password || !role) {
        return res.status(400).json({ message: 'Nombre de usuario, contraseña y rol son requeridos.' });
    }
    if (role !== 'admin' && role !== 'user') {
        return res.status(400).json({ message: 'El rol debe ser "admin" o "user".' });
    }

    try {
        const usersData = await fs.readFile(USERS_FILE, 'utf-8');
        const users = JSON.parse(usersData);

        if (users.find(u => u.username === username)) {
            return res.status(409).json({ message: 'El nombre de usuario ya existe.' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        users.push({ username, password: hashedPassword, role });

        await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
        res.status(201).json({ message: 'Usuario creado con éxito.' });

    } catch (error) {
        console.error('Error al crear el usuario:', error);
        res.status(500).json({ message: 'Error interno del servidor.' });
    }
});

app.delete('/api/users/:username', authenticateToken, isAdmin, async (req, res) => {
    const targetUsername = req.params.username;

    if (req.user.username === targetUsername) {
        return res.status(400).json({ message: 'No puedes eliminarte a ti mismo.' });
    }

    try {
        const usersData = await fs.readFile(USERS_FILE, 'utf-8');
        let users = JSON.parse(usersData);
        const initialLength = users.length;

        users = users.filter(u => u.username !== targetUsername);

        if (users.length === initialLength) {
            return res.status(404).json({ message: 'Usuario no encontrado.' });
        }

        await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
        res.status(200).json({ message: 'Usuario eliminado con éxito.' });

    } catch (error) {
        console.error('Error al eliminar el usuario:', error);
        res.status(500).json({ message: 'Error interno del servidor.' });
    }
});

// --- History Snapshot Logic ---

const HISTORY_DIR = path.join(DATA_DIR, 'history');

// Schedule a task to run every day at 23:59
cron.schedule('59 23 * * *', async () => {
    console.log('Running daily history snapshot...');
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0); // Start of the day
        const tomorrow = new Date(today);
        tomorrow.setDate(today.getDate() + 1); // Start of next day

        const files = await fs.readdir(DATA_DIR);
        const projectFiles = files.filter(file => file.endsWith('.json') && file !== 'users.json');

        for (const file of projectFiles) {
            const filePath = path.join(DATA_DIR, file);
            const fileContent = await fs.readFile(filePath, 'utf-8');
            const projectData = JSON.parse(fileContent);
            const wrsId = projectData.wrs;

            let projectModifications = [];

            const checkArrayForModifications = (arr, type) => {
                if (!arr || !Array.isArray(arr)) return;
                arr.forEach(item => {
                    if (item.updatedAt) {
                        const updatedAt = new Date(item.updatedAt);
                        if (updatedAt >= today && updatedAt < tomorrow) {
                            projectModifications.push({
                                ...item,
                                wrs: wrsId,
                                type: type,
                                snapshotDate: today.toISOString().split('T')[0]
                            });
                        }
                    }
                });
            };

            checkArrayForModifications(projectData.assembly, 'Ensamble');
            checkArrayForModifications(projectData.electrical, 'Prueba Eléctrica');
            checkArrayForModifications(projectData.engineering, 'Ingeniería');
            checkArrayForModifications(projectData.support, 'Soporte');
            checkArrayForModifications(projectData.quality, 'Calidad');

            if (projectModifications.length > 0) {
                const projectHistoryDir = path.join(HISTORY_DIR, wrsId);
                await fs.mkdir(projectHistoryDir, { recursive: true });
                
                const historyFileName = `${today.toISOString().split('T')[0]}.json`;
                const historyFilePath = path.join(projectHistoryDir, historyFileName);
                
                await fs.writeFile(historyFilePath, JSON.stringify(projectModifications, null, 2), 'utf-8');
                console.log(`Successfully created history snapshot for project ${wrsId}: ${historyFileName}`);
            }
        }
        console.log('Daily history snapshot finished.');

    } catch (error) {
        console.error('Error during daily history snapshot:', error);
    }
});

// --- API Endpoint for History ---

app.get('/api/history/:id', authenticateToken, async (req, res) => {
    const wrsId = req.params.id;
    const { startDate, endDate } = req.query;

    if (!startDate || !endDate) {
        return res.status(400).json({ message: 'Los parámetros startDate y endDate son requeridos.' });
    }

    const projectHistoryDir = path.join(HISTORY_DIR, wrsId);

    try {
        await fs.access(projectHistoryDir);
        const historyFiles = await fs.readdir(projectHistoryDir);

        const start = new Date(startDate);
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999); // Include the whole end day

        let results = [];

        for (const file of historyFiles) {
            const fileDateStr = path.basename(file, '.json');
            const fileDate = new Date(fileDateStr);

            if (fileDate >= start && fileDate <= end) {
                const filePath = path.join(projectHistoryDir, file);
                const fileContent = await fs.readFile(filePath, 'utf-8');
                results = results.concat(JSON.parse(fileContent));
            }
        }

        results.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
        res.json(results);

    } catch (error) {
        if (error.code === 'ENOENT') {
            // Directorio de historial para el proyecto no existe, devolver vacío
            return res.json([]);
        }
        console.error(`Error fetching history for ${wrsId}:`, error);
        res.status(500).json({ message: 'Error interno al obtener el historial.' });
    }
});


// --- Iniciar el servidor ---
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
    console.log(`Accesible en tu red local (LAN). Para encontrar tu IP, abre un terminal y ejecuta: ipconfig`);
});

// --- Inicialización de usuarios ---
async function initializeUsers() {
    try {
        await fs.access(USERS_FILE);
    } catch (error) {
        // El archivo no existe, crearlo con un usuario admin por defecto
        if (error.code === 'ENOENT') {
            console.log('Archivo de usuarios no encontrado. Creando uno nuevo con un administrador por defecto.');
            try {
                const defaultAdminPassword = 'admin'; // Cambiar esto en un entorno de producción
                const hashedPassword = await bcrypt.hash(defaultAdminPassword, 10);
                const defaultUsers = [{
                    username: 'admin',
                    password: hashedPassword,
                    role: 'admin'
                }];
                await fs.mkdir(DATA_DIR, { recursive: true });
                await fs.writeFile(USERS_FILE, JSON.stringify(defaultUsers, null, 2), 'utf-8');
                console.log(`Usuario por defecto 'admin' con contraseña '${defaultAdminPassword}' creado.`);
            } catch (initError) {
                console.error('Error al inicializar el archivo de usuarios:', initError);
            }
        }
    }
}

initializeUsers();
