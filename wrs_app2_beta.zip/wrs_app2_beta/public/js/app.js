
document.addEventListener('DOMContentLoaded', () => {

    // --- STATE ---
    let state = {
        currentUser: null,
        currentWrsData: null,
        technicianReportData: null, 
        dashboardHistoryData: null,
        reportFilters: {},
        currentlyEditingItem: { index: null, type: null },
        loginModal: null,
        registerModal: null,
        changePasswordModal: null,
        resetPasswordModal: null,
        userToResetPassword: null,
        editItemModal: null,
        editQualityLogModal: null,
        editLogModal: null,
        offcanvasMenu: null,
        actionAfterLogin: null, 
        projectPieChart: null, 
        projectBarChart: null,
    };

    // --- HELPERS ---
    const groupHistoryDataByCategory = (historyData) => {
        const grouped = { assembly: [], electrical: [], engineering: [], support: [], quality: [] };
        const typeMap = {
            'Ensamble': 'assembly',
            'Prueba Eléctrica': 'electrical',
            'Ingeniería': 'engineering',
            'Soporte': 'support',
            'Calidad': 'quality'
        };
        historyData.forEach(item => {
            const category = typeMap[item.type];
            if (category) {
                grouped[category].push(item);
            }
        });
        return grouped;
    };

    // --- SERVICES ---
    const authService = {
        TOKEN_KEY: 'wrs_token',
        USER_KEY: 'wrs_user',
        register: async (username, password) => {
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            if (!response.ok) {
                const err = await response.json();
                throw new Error(err.message);
            }
            return await response.json();
        },
        login: async (username, password) => {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            if (!response.ok) {
                const err = await response.json();
                throw new Error(err.message);
            }
            const { accessToken, user } = await response.json();
            localStorage.setItem(authService.TOKEN_KEY, accessToken);
            localStorage.setItem(authService.USER_KEY, JSON.stringify(user));
            state.currentUser = user;
            return user;
        },
        logout: () => {
            localStorage.removeItem(authService.TOKEN_KEY);
            localStorage.removeItem(authService.USER_KEY);
            state.currentUser = null;
            window.location.reload();
        },
        getToken: () => localStorage.getItem(authService.TOKEN_KEY),
        getUser: () => {
            if (state.currentUser) return state.currentUser;
            const user = localStorage.getItem(authService.USER_KEY);
            if (user) {
                state.currentUser = JSON.parse(user);
                return state.currentUser;
            }
            return null;
        },
        isAdmin: () => state.currentUser?.role === 'admin',
    };

    const apiService = {
        authFetch: async (url, options = {}) => {
            const token = authService.getToken();
            const headers = { 'Content-Type': 'application/json', ...options.headers };
            if (token) {
                headers['Authorization'] = `Bearer ${token}`;
            }
            const response = await fetch(url, { ...options, headers });
            const contentType = response.headers.get("content-type");

            if (response.ok) {
                if (contentType && contentType.indexOf("application/json") !== -1) {
                    return response.json();
                } else {
                    return response.text();
                }
            }

            let error;
            if (contentType && contentType.indexOf("application/json") !== -1) {
                error = await response.json();
            } else {
                const textError = await response.text();
                error = { message: textError || `Request failed with status ${response.status}` };
            }
            error.status = response.status;
            throw error;
        }
    };

    const dataService = {
        getHistory: (id, startDate, endDate) => apiService.authFetch(`/api/history/${id}?startDate=${startDate}&endDate=${endDate}`),
        getTechnicianReport: (name) => apiService.authFetch(`/api/report/technician/${name}`),
        getProjectData: (wrsNumber) => apiService.authFetch(`/api/wrs/${wrsNumber}`),
        saveWrsData: async (wrsData) => {
            const response = await apiService.authFetch(`/api/wrs/${wrsData.wrs}`, {
                method: 'POST',
                body: JSON.stringify(wrsData)
            });
            if (response.newVersion) {
                state.currentWrsData.version = response.newVersion;
            }
            return response;
        },
        deleteWrsData: (wrsNumber) => apiService.authFetch(`/api/wrs/${wrsNumber}`, { method: 'DELETE' }),
        getUsers: () => apiService.authFetch('/api/users'),
        createUser: (username, password, role) => apiService.authFetch('/api/users', { method: 'POST', body: JSON.stringify({ username, password, role }) }),
        deleteUser: (username) => apiService.authFetch(`/api/users/${username}`, { method: 'DELETE' }),
        changePassword: (currentPassword, newPassword) => apiService.authFetch('/api/user/password', { method: 'POST', body: JSON.stringify({ currentPassword, newPassword }) }),
        resetPassword: (username, newPassword) => apiService.authFetch(`/api/users/${username}/reset-password`, { method: 'POST', body: JSON.stringify({ newPassword }) }),
    };

    const recentProjectsService = {
        KEY: 'recentWrsProjects',
        MAX_RECENTS: 5,
        get() { return JSON.parse(localStorage.getItem(this.KEY) || '[]'); },
        add(wrsNumber) {
            if (!wrsNumber) return;
            let recents = this.get().filter(r => r !== wrsNumber);
            recents.unshift(wrsNumber);
            localStorage.setItem(this.KEY, JSON.stringify(recents.slice(0, this.MAX_RECENTS)));
        }
    };

    // --- DOM Elements ---
    const dom = {
        loginModalEl: document.getElementById('loginModal'),
        loginForm: document.getElementById('login-form'),
        loginError: document.getElementById('login-error'),
        registerModalEl: document.getElementById('registerModal'),
        registerForm: document.getElementById('register-form'),
        registerMessage: document.getElementById('register-message'),
        showRegisterModal: document.getElementById('show-register-modal'),
        showLoginModal: document.getElementById('show-login-modal'),
        changePasswordModalEl: document.getElementById('changePasswordModal'),
        changePasswordForm: document.getElementById('change-password-form'),
        changePasswordMessage: document.getElementById('change-password-message'),
        changePasswordBtn: document.getElementById('change-password-btn'),
        resetPasswordModalEl: document.getElementById('resetPasswordModal'),
        resetPasswordForm: document.getElementById('reset-password-form'),
        resetPasswordMessage: document.getElementById('reset-password-message'),
        resetPasswordUsername: document.getElementById('reset-password-username'),
        appContainer: document.getElementById('app-container'),
        userInfo: document.getElementById('user-info'),
        logoutBtn: document.getElementById('logout-btn'),
        adminViewBtn: document.getElementById('admin-view-btn'),
        homeView: document.getElementById('home-view'),
        projectView: document.getElementById('project-view'),
        adminView: document.getElementById('admin-view'),
        dashboardView: document.getElementById('dashboard-view'),
        dashboardLink: document.getElementById('dashboard-link'),
        reportView: document.getElementById('report-view'),
        reportLink: document.getElementById('report-link'),
        reportForm: document.getElementById('report-form'),
        technicianInput: document.getElementById('technician-input'),
        reportResultsContainer: document.getElementById('report-results-container'),
        reportTableBody: document.getElementById('report-table-body'),
        reportTableHeader: document.querySelector('#report-table-body').previousElementSibling, // thead
        exportReportBtn: document.getElementById('export-report-excel'),
        reportTotalAccumulated: document.getElementById('report-total-accumulated'),
        reportTotalRemaining: document.getElementById('report-total-remaining'),
        reportTotalSavings: document.getElementById('report-total-savings'),
        backToHomeBtn: document.getElementById('back-to-home'),
        wrsForm: document.getElementById('wrs-form'),
        wrsInput: document.getElementById('wrs-input'),
        offcanvasMenuEl: document.getElementById('offcanvasMenu'),
        offcanvasWrsForm: document.getElementById('offcanvas-wrs-form'),
        importExcelHomeBtn: document.getElementById('import-excel-home'),
        recentProjectsList: document.getElementById('recent-projects-list'),
        importExcelInput: document.getElementById('import-excel-input'),
        projectTitle: document.getElementById('project-title'),
        exportExcelProjectBtn: document.getElementById('export-excel-project'),
        deleteWrsBtn: document.getElementById('delete-wrs'),
        usersTableBody: document.getElementById('users-table-body'),
        createUserForm: document.getElementById('create-user-form'),
        createUserError: document.getElementById('create-user-error'),
        editItemModalEl: document.getElementById('editItemModal'),
        editItemForm: document.getElementById('edit-item-form'),
        editQualityLogModalEl: document.getElementById('editQualityLogModal'),
        editQualityLogForm: document.getElementById('edit-quality-log-form'),
        editLogModalEl: document.getElementById('editLogModal'),
        editLogForm: document.getElementById('edit-log-form'),
        projectTabsContent: document.getElementById('project-tabs-content'),
        projectPieChart: document.getElementById('project-pie-chart'),
        projectBarChart: document.getElementById('project-bar-chart'),
        projectTotalTime: document.getElementById('project-total-time'),
        dashboardHistoryForm: document.getElementById('dashboard-history-form'),
        dashboardStartDate: document.getElementById('dashboard-start-date'),
        dashboardEndDate: document.getElementById('dashboard-end-date'),
        dashboardHistoryResultsContainer: document.getElementById('dashboard-history-results-container'),
        dashboardHistoryTableBody: document.getElementById('dashboard-history-table-body'),
        exportDashboardHistoryBtn: document.getElementById('export-dashboard-history-excel'),
        clearDashboardHistoryFilter: document.getElementById('clear-dashboard-history-filter'),
    };

    // --- VIEW MANAGEMENT ---
    const showView = (view) => {
        [dom.homeView, dom.projectView, dom.adminView, dom.dashboardView, dom.reportView].forEach(v => v.style.display = 'none');
        
        document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());

        if (view === dom.homeView) {
            dom.backToHomeBtn.style.display = 'none';
            dom.dashboardLink.style.display = 'none';
            renderRecentProjects();
        } else {
            dom.backToHomeBtn.style.display = 'block';
            if(state.currentUser && state.currentWrsData) {
                dom.dashboardLink.style.display = 'block';
            }
        }
        view.style.display = 'block';
    };

    const setupUIForUser = () => {
        const user = authService.getUser();
        dom.appContainer.style.display = 'block';

        if (user) {
            dom.userInfo.textContent = `Usuario: ${user.username} (${user.role})`;
            dom.userInfo.style.display = 'inline-block';
            dom.logoutBtn.textContent = 'Cerrar Sesión';
            dom.reportLink.style.display = 'block';
            dom.changePasswordBtn.style.display = 'block';

            if (authService.isAdmin()) {
                dom.adminViewBtn.style.display = 'block';
                dom.deleteWrsBtn.style.display = 'inline-block';
            } else {
                dom.adminViewBtn.style.display = 'none';
                dom.deleteWrsBtn.style.display = 'none';
            }
        } else { // Guest user
            dom.userInfo.style.display = 'none';
            dom.adminViewBtn.style.display = 'none';
            dom.deleteWrsBtn.style.display = 'none';
            dom.dashboardLink.style.display = 'none';
            dom.reportLink.style.display = 'none';
            dom.changePasswordBtn.style.display = 'none';
            dom.logoutBtn.textContent = 'Iniciar Sesión';
        }
        if(state.currentWrsData) renderProject();
    };

    // --- RENDERING ---
    const renderProject = () => {
        if (!state.currentWrsData) return;
        dom.projectTitle.textContent = `Proyecto WRS: ${state.currentWrsData.wrs}`;
        ['assembly', 'electrical'].forEach(type => renderItemsTable(type));
        ['engineering', 'support'].forEach(type => renderLogTable(type));
        renderQualityLogTable('quality');
    };

    const renderProjectCharts = (data, titleSuffix = '') => {
        const sourceData = data || state.currentWrsData;
        if (!sourceData) return;

        if (state.projectPieChart) state.projectPieChart.destroy();
        if (state.projectBarChart) state.projectBarChart.destroy();

        const sumProperty = (arr, prop) => (arr && Array.isArray(arr)) ? arr.reduce((sum, item) => sum + (item[prop] || 0), 0) : 0;

        const assemblyTime = sumProperty(sourceData.assembly, 'accumulatedTime');
        const electricalTime = sumProperty(sourceData.electrical, 'accumulatedTime');
        const engineeringTime = sumProperty(sourceData.engineering, 'hours');
        const supportTime = sumProperty(sourceData.support, 'hours');
        const totalTime = assemblyTime + electricalTime + engineeringTime + supportTime;

        dom.projectTotalTime.textContent = totalTime.toFixed(2);

        const chartLabels = ['Ensamble', 'Prueba Eléctrica', 'Ingeniería', 'Soporte'];
        const chartDataPoints = [assemblyTime, electricalTime, engineeringTime, supportTime];
        const chartBackgroundColors = ['rgba(54, 162, 235, 0.8)', 'rgba(255, 206, 86, 0.8)', 'rgba(75, 192, 192, 0.8)', 'rgba(255, 99, 132, 0.8)'];
        const chartBorderColors = ['rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)', 'rgba(75, 192, 192, 1)', 'rgba(255, 99, 132, 1)'];

        const finalTitle = `Horas por Categoría para WRS: ${state.currentWrsData.wrs} ${titleSuffix}`.trim();

        state.projectPieChart = new Chart(dom.projectPieChart.getContext('2d'), {
            type: 'doughnut',
            data: { labels: chartLabels, datasets: [{ label: 'Horas', data: chartDataPoints, backgroundColor: chartBackgroundColors, borderColor: chartBorderColors, borderWidth: 1 }] },
            options: { responsive: true, plugins: { legend: { position: 'top' }, title: { display: false } } }
        });

        state.projectBarChart = new Chart(dom.projectBarChart.getContext('2d'), {
            type: 'bar',
            data: { labels: chartLabels, datasets: [{ label: 'Horas', data: chartDataPoints, backgroundColor: chartBackgroundColors, borderColor: chartBorderColors, borderWidth: 1 }] },
            options: { responsive: true, plugins: { legend: { display: false }, title: { display: true, text: finalTitle } }, scales: { y: { beginAtZero: true, title: { display: true, text: 'Horas' } } } }
        });
    };

    const renderDashboardHistoryTable = (data) => {
        dom.dashboardHistoryTableBody.innerHTML = '';
        if (!data || data.length === 0) {
            dom.dashboardHistoryTableBody.innerHTML = '<tr><td colspan="7" class="text-center">No se encontraron registros para el rango de fechas seleccionado.</td></tr>';
        } else {
            data.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.type}</td>
                    <td>${item.partNumber || 'N/A'}</td>
                    <td>${item.comment || ''}</td>
                    <td>${item.tecnico || ''}</td>
                    <td>${(item.hours || item.accumulatedTime || 0).toFixed(2)}</td>
                    <td>${new Date(item.updatedAt).toLocaleString()}</td>
                    <td>${new Date(item.snapshotDate).toLocaleDateString()}</td>
                `;
                dom.dashboardHistoryTableBody.appendChild(row);
            });
        }
        dom.dashboardHistoryResultsContainer.style.display = 'block';
    };

    const applyReportFilters = () => {
        if (!state.technicianReportData) return;
        let filteredData = [...state.technicianReportData];
        for (const key in state.reportFilters) {
            const filterValue = state.reportFilters[key].toLowerCase();
            if (filterValue) {
                filteredData = filteredData.filter(item => {
                    const itemValue = item[key] ? String(item[key]).toLowerCase() : '';
                    return itemValue.includes(filterValue);
                });
            }
        }
        renderTechnicianReport(filteredData);
    };

    const renderTechnicianReport = (data) => {
        dom.reportTableBody.innerHTML = '';
        let totalAccumulated = 0;
        let totalEstimated = 0;

        if (!data || data.length === 0) {
            dom.reportTableBody.innerHTML = '<tr><td colspan="9" class="text-center">No se encontraron datos que coincidan con los filtros.</td></tr>';
        } else {
            data.forEach(item => {
                totalAccumulated += item.accumulatedTime || 0;
                totalEstimated += item.estimatedTime || 0;
                const row = document.createElement('tr');
                const savingsClass = item.savingsPercentage >= 0 ? 'text-success' : 'text-danger';
                row.innerHTML = `
                    <td>${item.wrs}</td>
                    <td>${item.type}</td>
                    <td>${item.partNumber}</td>
                    <td>${item.quantity || 'N/A'}</td>
                    <td>${(item.accumulatedTime || 0).toFixed(2)}</td>
                    <td class="${item.remainingTime < 0 ? 'text-danger' : ''}">${(item.remainingTime || 0).toFixed(2)}</td>
                    <td class="${savingsClass}">${(item.savingsPercentage || 0).toFixed(2)}%</td>
                    <td>${item.comment}</td>
                    <td>${new Date(item.updatedAt).toLocaleString()}</td>
                `;
                dom.reportTableBody.appendChild(row);
            });
        }

        const totalRemaining = totalEstimated - totalAccumulated;
        const totalSavings = totalEstimated > 0 ? (totalRemaining / totalEstimated) * 100 : 0;
        
        dom.reportTotalAccumulated.textContent = totalAccumulated.toFixed(2);
        dom.reportTotalRemaining.textContent = totalRemaining.toFixed(2);
        dom.reportTotalSavings.textContent = `${totalSavings.toFixed(2)}%`;
        dom.reportTotalRemaining.className = totalRemaining < 0 ? 'text-danger' : '';
        dom.reportTotalSavings.className = totalSavings >= 0 ? 'text-success' : 'text-danger';

        dom.reportResultsContainer.style.display = 'block';
    };

    const renderItemsTable = (type) => {
        const tableBody = document.getElementById(`${type}-table-body`);
        if (!tableBody) return;
        const items = state.currentWrsData[type] || [];
        const searchTerm = document.getElementById('search-input').value.trim().toLowerCase();
        const filteredItems = items.map((item, index) => ({ ...item, originalIndex: index })).filter(item => !searchTerm || [item.number, item.tecnico || '', item.comment || ''].join(' ').toLowerCase().includes(searchTerm));
        tableBody.innerHTML = '';
        filteredItems.forEach((item, filteredIndex) => {
            const difference = item.estimatedTime - item.accumulatedTime;
            let timeInfoHtml = 'N/A';
            if (item.estimatedTime > 0) {
                const timeProgress = (item.accumulatedTime / item.estimatedTime) * 100;
                const timeSaved = 100 - timeProgress;
                const progressBarClass = timeProgress > 100 ? 'bg-danger' : 'bg-info';
                const progressText = `${timeProgress.toFixed(0)}% Usado`;
                let savedText = '';
                if (timeSaved >= 0) {
                    savedText = `<span class="text-success">${timeSaved.toFixed(0)}% Ahorrado</span>`;
                } else {
                    savedText = `<span class="text-danger">${Math.abs(timeSaved).toFixed(0)}% Excedido</span>`;
                }
                timeInfoHtml = `<div class="progress" style="height: 20px;"><div class="progress-bar ${progressBarClass}" style="width: ${Math.min(100, timeProgress)}%">${progressText}</div></div><div class="text-center small mt-1">${savedText}</div>`;
            } else {
                timeInfoHtml = 'N/A';
            }
            const row = document.createElement('tr');
            let rowContent = '';
            if (type === 'assembly') {
                rowContent = `<td>${filteredIndex + 1}</td><td>${item.number}</td><td>${item.quantity}</td><td>${item.estimatedTime.toFixed(2)}</td><td>${item.accumulatedTime.toFixed(2)}</td><td class="${difference < 0 ? 'text-danger' : ''}">${difference.toFixed(2)}</td><td>${timeInfoHtml}</td><td><div class="progress"><div class="progress-bar bg-success" style="width: ${item.manualProgress || 0}%">${item.manualProgress || 0}%</div></div></td><td>${item.tecnico || ''}</td><td>${item.comment || ''}</td><td>${item.updatedAt ? new Date(item.updatedAt).toLocaleString() : 'N/A'}</td><td><button class="btn btn-sm btn-primary edit-item-btn" data-index="${item.originalIndex}" data-type="${type}">Editar</button><button class="btn btn-sm btn-outline-danger delete-item-btn" data-index="${item.originalIndex}" data-type="${type}">Eliminar</button></td>`;
            } else {
                rowContent = `<td>${filteredIndex + 1}</td><td>${item.number}</td><td>${item.quantity}</td><td>${item.estimatedTime.toFixed(2)}</td><td>${item.accumulatedTime.toFixed(2)}</td><td class="${difference < 0 ? 'text-danger' : ''}">${difference.toFixed(2)}</td><td>${timeInfoHtml}</td><td><div class="progress"><div class="progress-bar bg-success" style="width: ${item.manualProgress || 0}%">${item.manualProgress || 0}%</div></div></td><td>${item.tecnico || ''}</td><td>${item.updatedAt ? new Date(item.updatedAt).toLocaleString() : 'N/A'}</td><td><button class="btn btn-sm btn-primary edit-item-btn" data-index="${item.originalIndex}" data-type="${type}">Editar</button><button class="btn btn-sm btn-outline-danger delete-item-btn" data-index="${item.originalIndex}" data-type="${type}">Eliminar</button></td>`;
            }
            row.innerHTML = rowContent;
            tableBody.appendChild(row);
        });
    };

    const renderLogTable = (type) => {
        const tableBody = document.getElementById(`${type}-log-table-body`);
        if (!tableBody) return;
        const totalHoursEl = document.getElementById(`${type}-total-hours`);
        const logEntries = state.currentWrsData[type] || [];
        const searchTerm = document.getElementById('search-input').value.trim().toLowerCase();
        const filteredEntries = logEntries.map((entry, index) => ({ ...entry, originalIndex: index })).filter(entry => !searchTerm || [entry.partNumber || '', entry.comment || ''].join(' ').toLowerCase().includes(searchTerm));
        tableBody.innerHTML = '';
        let totalHours = 0;
        filteredEntries.forEach((entry, filteredIndex) => {
            totalHours += entry.hours;
            const row = document.createElement('tr');
            row.innerHTML = `<td>${filteredIndex + 1}</td><td>${entry.hours.toFixed(2)}</td><td>${entry.partNumber || 'N/A'}</td><td>${entry.comment}</td><td>${entry.updatedAt ? new Date(entry.updatedAt).toLocaleString() : 'N/A'}</td><td><button class="btn btn-sm btn-primary edit-log-btn" data-index="${entry.originalIndex}" data-type="${type}">Editar</button><button class="btn btn-sm btn-outline-danger delete-log-btn" data-index="${entry.originalIndex}" data-type="${type}">Eliminar</button></td>`;
            tableBody.appendChild(row);
        });
        if (totalHoursEl) totalHoursEl.textContent = `${totalHours.toFixed(2)} horas`;
    };

    const renderQualityLogTable = (type) => {
        const tableBody = document.getElementById(`${type}-log-table-body`);
        if (!tableBody) return;
        const logEntries = state.currentWrsData[type] || [];
        const searchTerm = document.getElementById('search-input').value.trim().toLowerCase();
        const filteredEntries = logEntries.map((entry, index) => ({ ...entry, originalIndex: index })).filter(entry => !searchTerm || [entry.partNumber || '', entry.comment || '', entry.user || ''].join(' ').toLowerCase().includes(searchTerm));
        tableBody.innerHTML = '';
        filteredEntries.forEach((entry, filteredIndex) => {
            const row = document.createElement('tr');
            row.innerHTML = `<td>${filteredIndex + 1}</td><td>${entry.partNumber || 'N/A'}</td><td>${entry.status}</td><td>${entry.comment}</td><td>${entry.user}</td><td>${entry.updatedAt ? new Date(entry.updatedAt).toLocaleString() : 'N/A'}</td><td><button class="btn btn-sm btn-primary edit-log-btn" data-index="${entry.originalIndex}" data-type="${type}">Editar</button><button class="btn btn-sm btn-outline-danger delete-log-btn" data-index="${entry.originalIndex}" data-type="${type}">Eliminar</button></td>`;
            tableBody.appendChild(row);
        });
    };

    const renderRecentProjects = () => {
        dom.recentProjectsList.innerHTML = '';
        const recents = recentProjectsService.get();
        if (recents.length === 0) {
            dom.recentProjectsList.innerHTML = '<p class="text-muted text-center">No hay proyectos recientes.</p>';
            return;
        }
        recents.forEach(wrs => {
            const item = document.createElement('button');
            item.className = 'list-group-item list-group-item-action recent-item';
            item.textContent = wrs;
            item.dataset.wrs = wrs;
            dom.recentProjectsList.appendChild(item);
        });
    };

    const renderUsersTable = async () => {
        try {
            const users = await dataService.getUsers();
            dom.usersTableBody.innerHTML = '';
            users.forEach(user => {
                const row = document.createElement('tr');
                row.innerHTML = `<td>${user.username}</td> <td>${user.role}</td><td>${state.currentUser.username !== user.username ? `<button class="btn btn-sm btn-danger delete-user-btn" data-username="${user.username}">Eliminar</button> <button class="btn btn-sm btn-warning reset-password-btn" data-username="${user.username}">Resetear Contraseña</button>` : ''}</td>`;
                dom.usersTableBody.appendChild(row);
            });
        } catch (error) {
            handleSaveError(error, renderUsersTable);
        }
    };

    // --- ERROR HANDLING ---
    const handleSaveError = async (error, saveFunction) => {
        if (error.status === 401 || error.status === 403) {
            if (confirm((error.message || "Esta acción requiere permisos.") + '\n¿Desea iniciar sesión para continuar?')) {
                state.actionAfterLogin = saveFunction;
                state.loginModal.show();
            } else {
                alert('Acción cancelada.');
            }
        } else if (error.status === 409) {
            if (confirm(error.message + '\n¿Deseas recargar el proyecto para ver los últimos cambios?')) {
                dom.wrsForm.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
            }
        } else {
            alert('Ocurrió un error: ' + error.message || 'Error inesperado.');
        }
    };

    // --- EVENT HANDLERS ---
    const handleLoginFormSubmit = async (e) => {
        e.preventDefault();
        const username = dom.loginForm.elements['username-input'].value;
        const password = dom.loginForm.elements['password-input'].value;
        try {
            dom.loginError.style.display = 'none';
            const user = await authService.login(username, password);
            state.loginModal.hide();
            if (state.actionAfterLogin) {
                console.log('Reintentando la acción anterior...');
                const action = state.actionAfterLogin;
                state.actionAfterLogin = null;
                await action();
            }
            setupUIForUser();
        } catch (error) {
            dom.loginError.textContent = error.message;
            dom.loginError.style.display = 'block';
        }
    };

    const handleRegisterFormSubmit = async (e) => {
        e.preventDefault();
        const username = dom.registerForm.elements['register-username-input'].value;
        const password = dom.registerForm.elements['register-password-input'].value;
        try {
            const result = await authService.register(username, password);
            dom.registerMessage.textContent = result.message;
            dom.registerMessage.className = 'alert alert-success';
            dom.registerMessage.style.display = 'block';
            dom.registerForm.reset();
        } catch (error) {
            dom.registerMessage.textContent = error.message;
            dom.registerMessage.className = 'alert alert-danger';
            dom.registerMessage.style.display = 'block';
        }
    };

    const handleChangePasswordFormSubmit = async (e) => {
        e.preventDefault();
        const currentPassword = dom.changePasswordForm.elements['current-password-input'].value;
        const newPassword = dom.changePasswordForm.elements['new-password-input-change'].value;
        const confirmPassword = dom.changePasswordForm.elements['confirm-password-input'].value;

        if (newPassword !== confirmPassword) {
            dom.changePasswordMessage.textContent = 'Las nuevas contraseñas no coinciden.';
            dom.changePasswordMessage.className = 'alert alert-danger';
            dom.changePasswordMessage.style.display = 'block';
            return;
        }

        try {
            const result = await dataService.changePassword(currentPassword, newPassword);
            dom.changePasswordMessage.textContent = result.message;
            dom.changePasswordMessage.className = 'alert alert-success';
            dom.changePasswordMessage.style.display = 'block';
            dom.changePasswordForm.reset();
        } catch (error) {
            dom.changePasswordMessage.textContent = error.message;
            dom.changePasswordMessage.className = 'alert alert-danger';
            dom.changePasswordMessage.style.display = 'block';
        }
    };

    const handleResetPasswordFormSubmit = async (e) => {
        e.preventDefault();
        const newPassword = dom.resetPasswordForm.elements['new-password-input-reset'].value;
        if (!state.userToResetPassword) return;

        try {
            const result = await dataService.resetPassword(state.userToResetPassword, newPassword);
            dom.resetPasswordMessage.textContent = result.message;
            dom.resetPasswordMessage.className = 'alert alert-success';
            dom.resetPasswordMessage.style.display = 'block';
            dom.resetPasswordForm.reset();
            setTimeout(() => {
                state.resetPasswordModal.hide();
            }, 2000);
        } catch (error) {
            dom.resetPasswordMessage.textContent = error.message;
            dom.resetPasswordMessage.className = 'alert alert-danger';
            dom.resetPasswordMessage.style.display = 'block';
        }
    };

    const handleLoginLogoutClick = (e) => {
        e.preventDefault();
        if (authService.getUser()) {
            authService.logout();
        } else {
            state.actionAfterLogin = null;
            state.loginModal.show();
        }
    };
    
    const handleAdminViewClick = (e) => {
        e.preventDefault();
        const openAdminView = () => { renderUsersTable(); showView(dom.adminView); };
        if (authService.isAdmin()) {
            openAdminView();
        } else {
            handleSaveError({ status: 403, message: 'La gestión de usuarios requiere permisos de administrador.' }, openAdminView);
        }
    };

    const handleDashboardClick = (e) => {
        e.preventDefault();
        if (state.currentWrsData) { 
            renderProjectCharts(); 
            dom.dashboardHistoryResultsContainer.style.display = 'none';
            dom.dashboardHistoryTableBody.innerHTML = '';
            dom.dashboardHistoryForm.reset();
            showView(dom.dashboardView); 
        }
    };

    const handleDashboardHistoryFormSubmit = async (e) => {
        e.preventDefault();
        if (!state.currentWrsData) {
            alert('Por favor, carga un proyecto primero.');
            return;
        }
        const wrsId = state.currentWrsData.wrs;
        const startDate = dom.dashboardStartDate.value;
        const endDate = dom.dashboardEndDate.value;

        if (!startDate || !endDate) {
            alert('Por favor, seleccione una fecha de inicio y una fecha de fin.');
            return;
        }

        const fetchHistory = async () => {
            try {
                const historyData = await dataService.getHistory(wrsId, startDate, endDate);
                state.dashboardHistoryData = historyData;
                renderDashboardHistoryTable(historyData);
                const groupedData = groupHistoryDataByCategory(historyData);
                renderProjectCharts(groupedData, '(Filtrado)');

            } catch (error) {
                await handleSaveError(error, fetchHistory);
            }
        };
        await fetchHistory();
    };

    const handleReportFormSubmit = async (e) => {
        e.preventDefault();
        const techName = dom.technicianInput.value.trim();
        if (!techName) return;
        const generateReport = async () => {
            const reportData = await dataService.getTechnicianReport(techName);
            state.technicianReportData = reportData;
            state.reportFilters = {}; // Clear previous filters
            dom.reportTableHeader.querySelectorAll('.filter-input').forEach(input => input.value = '');
            applyReportFilters();
        };
        try { await generateReport(); } 
        catch (error) { await handleSaveError(error, generateReport); }
    };

    const handleReportFilterChange = (e) => {
        const key = e.target.dataset.filterKey;
        const value = e.target.value;
        state.reportFilters[key] = value;
        applyReportFilters();
    };

    const handleOffcanvasWrsFormSubmit = (e) => {
        e.preventDefault();
        const wrsInput = e.target.elements['offcanvas-wrs-input'];
        const wrsNumber = wrsInput.value.trim();
        if (wrsNumber) {
            dom.wrsInput.value = wrsNumber;
            dom.wrsForm.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
            wrsInput.value = '';
            state.offcanvasMenu.hide();
        }
    };

    const handleWrsFormSubmit = async (e) => {
        e.preventDefault();
        const wrsNumber = dom.wrsInput.value.trim();
        if (!wrsNumber) return;
        try {
            let data = await dataService.getProjectData(wrsNumber);
            if (!data.version) data.version = 0;
            if (data.parts) { data.assembly = [...data.parts]; delete data.parts; }
            if (data.electricalTest) { data.electrical = [...data.electricalTest]; delete data.electricalTest; }
            if (typeof data.engineeringHours === 'number') data.engineering = [{ hours: data.engineeringHours, partNumber: 'N/A', comment: 'Horas importadas' }];
            if (typeof data.supportHours === 'number') data.support = [{ hours: data.supportHours, partNumber: 'N/A', comment: 'Horas importadas' }];
            ['assembly', 'electrical', 'engineering', 'support', 'quality'].forEach(arr => { if (!Array.isArray(data[arr])) data[arr] = []; });
            state.currentWrsData = data;
            recentProjectsService.add(wrsNumber);
            renderProject();
            showView(dom.projectView);
            if (state.currentUser) dom.dashboardLink.style.display = 'block';
        } catch (error) { alert(error.message); }
    };

    const handleExcelImport = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        excelService.importWrsFromExcel(file, async (importedData) => {
            if (confirm(`¿Quieres cargar los datos para el WRS ${importedData.wrs}?`)){
                state.currentWrsData = importedData;
                if (!state.currentWrsData.version) state.currentWrsData.version = 0;
                const saveFunction = async () => {
                    await dataService.saveWrsData(state.currentWrsData);
                    recentProjectsService.add(importedData.wrs);
                    renderProject();
                    showView(dom.projectView);
                };
                try { await saveFunction(); } catch (error) { await handleSaveError(error, saveFunction); }
            }
        });
        e.target.value = '';
    };

    const handleRecentProjectClick = (e) => {
        if (e.target.classList.contains('recent-item')) {
            dom.wrsInput.value = e.target.dataset.wrs;
            dom.wrsForm.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
        }
    };

    const handleAddItemFormSubmit = async (e) => {
        e.preventDefault();
        const type = e.target.dataset.type;
        if (!type) return;
        const newItem = { number: document.getElementById(`${type}-number-input`).value.trim(), quantity: parseInt(document.getElementById(`${type}-quantity-input`).value, 10), estimatedTime: parseFloat(document.getElementById(`${type}-estimated-time-input`).value), accumulatedTime: 0, manualProgress: 0, tecnico: state.currentUser ? state.currentUser.username : '', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
        if (newItem.number && newItem.quantity > 0 && !isNaN(newItem.estimatedTime)) {
            state.currentWrsData[type].unshift(newItem);
            const saveFunction = async () => { await dataService.saveWrsData(state.currentWrsData); renderProject(); e.target.reset(); };
            try { await saveFunction(); } catch (error) { await handleSaveError(error, saveFunction); }
        }
    };

    const handleAddLogSubmit = async (e) => {
        e.preventDefault();
        const type = e.target.dataset.type;
        if (!type) return;
        let newLogEntry;
        if (type === 'quality') {
            newLogEntry = { partNumber: document.getElementById('quality-part-number-input').value.trim(), status: document.getElementById('quality-status-input').value, comment: document.getElementById('quality-comment-input').value.trim(), user: document.getElementById('quality-user-input').value.trim(), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
            if (!newLogEntry.partNumber || !newLogEntry.comment || !newLogEntry.user) { alert('Número de parte, comentario y usuario son requeridos.'); return; }
        } else {
            newLogEntry = { hours: parseFloat(document.getElementById(`${type}-hours-input`).value), partNumber: document.getElementById(`${type}-part-number-input`).value.trim(), comment: document.getElementById(`${type}-comment-input`).value.trim(), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
            if (!newLogEntry.comment || isNaN(newLogEntry.hours) || newLogEntry.hours <= 0) { alert('Comentario y horas (mayores a 0) son requeridos.'); return; }
        }
        state.currentWrsData[type].unshift(newLogEntry);
        const saveFunction = async () => { await dataService.saveWrsData(state.currentWrsData); renderProject(); e.target.reset(); };
        try { await saveFunction(); } catch (error) { await handleSaveError(error, saveFunction); }
    };

    const handleItemsTableClick = async (e) => {
        const target = e.target;
        if (!target) return;
        const type = target.dataset.type;
        const index = parseInt(target.dataset.index, 10);
        if (!type || isNaN(index)) return;
        if (target.classList.contains('edit-item-btn')) {
            state.currentlyEditingItem = { index, type };
            const item = state.currentWrsData[type][index];
            dom.editItemForm.elements['edit-item-number'].value = item.number;
            dom.editItemForm.elements['edit-item-quantity'].value = item.quantity;
            dom.editItemForm.elements['edit-item-estimated-time'].value = item.estimatedTime;
            dom.editItemForm.elements['edit-item-accumulated-time'].value = item.accumulatedTime;
            dom.editItemForm.elements['edit-item-manual-progress'].value = item.manualProgress || 0;
            dom.editItemForm.elements['edit-item-tecnico'].value = item.tecnico || (state.currentUser ? state.currentUser.username : '');
            dom.editItemForm.elements['edit-item-comment'].value = item.comment || '';
            state.editItemModal.show();
        } else if (target.classList.contains('delete-item-btn')) {
            const item = state.currentWrsData[type][index];
            if (confirm(`¿Seguro que quieres eliminar el componente ${item.number}?`)) {
                state.currentWrsData[type].splice(index, 1);
                const saveFunction = async () => { await dataService.saveWrsData(state.currentWrsData); renderProject(); };
                try { await saveFunction(); } catch (error) { await handleSaveError(error, saveFunction); }
            }
        }
    };

    const handleLogTableClick = async (e) => {
        const target = e.target;
        if (!target) return;
        const type = target.dataset.type;
        const index = parseInt(target.dataset.index, 10);
        if (!type || isNaN(index)) return;
        if (target.classList.contains('edit-log-btn')) {
            if (type === 'quality') {
                state.currentlyEditingItem = { index, type };
                const entry = state.currentWrsData[type][index];
                dom.editQualityLogForm.elements['edit-quality-part-number'].value = entry.partNumber;
                dom.editQualityLogForm.elements['edit-quality-status'].value = entry.status;
                dom.editQualityLogForm.elements['edit-quality-comment'].value = entry.comment || '';
                dom.editQualityLogForm.elements['edit-quality-user'].value = entry.user;
                state.editQualityLogModal.show();
            } else if (type === 'engineering' || type === 'support') {
                state.currentlyEditingItem = { index, type };
                const entry = state.currentWrsData[type][index];
                dom.editLogForm.elements['edit-log-hours'].value = entry.hours;
                dom.editLogForm.elements['edit-log-part-number'].value = entry.partNumber;
                dom.editLogForm.elements['edit-log-comment'].value = entry.comment || '';
                state.editLogModal.show();
            }
        } else if (target.classList.contains('delete-log-btn')) {
            const entry = state.currentWrsData[type][index];
            if (confirm(`¿Seguro que quieres eliminar la entrada de log: "${entry.comment}"?`)) {
                state.currentWrsData[type].splice(index, 1);
                const saveFunction = async () => { await dataService.saveWrsData(state.currentWrsData); renderProject(); };
                try { await saveFunction(); } catch (error) { await handleSaveError(error, saveFunction); }
            }
        }
    };

    const handleEditItemFormSubmit = async (e) => {
        e.preventDefault();
        const { index, type } = state.currentlyEditingItem;
        if (index === null || !type) return;
        const [item] = state.currentWrsData[type].splice(index, 1);
        item.number = dom.editItemForm.elements['edit-item-number'].value.trim();
        item.quantity = parseInt(dom.editItemForm.elements['edit-item-quantity'].value, 10);
        item.estimatedTime = parseFloat(dom.editItemForm.elements['edit-item-estimated-time'].value);
        item.accumulatedTime = parseFloat(dom.editItemForm.elements['edit-item-accumulated-time'].value);
        item.manualProgress = parseInt(dom.editItemForm.elements['edit-item-manual-progress'].value, 10);
        item.tecnico = dom.editItemForm.elements['edit-item-tecnico'].value.trim();
        item.comment = dom.editItemForm.elements['edit-item-comment'].value.trim();
        item.updatedAt = new Date().toISOString();
        state.currentWrsData[type].unshift(item);
        const saveFunction = async () => { await dataService.saveWrsData(state.currentWrsData); renderProject(); state.editItemModal.hide(); state.currentlyEditingItem = { index: null, type: null }; };
        try { await saveFunction(); } catch (error) { await handleSaveError(error, saveFunction); }
    };

    const handleEditQualityLogFormSubmit = async (e) => {
        e.preventDefault();
        const { index, type } = state.currentlyEditingItem;
        if (index === null || type !== 'quality') return;
        const entry = state.currentWrsData[type][index];
        entry.partNumber = dom.editQualityLogForm.elements['edit-quality-part-number'].value.trim();
        entry.status = dom.editQualityLogForm.elements['edit-quality-status'].value;
        entry.comment = dom.editQualityLogForm.elements['edit-quality-comment'].value.trim();
        entry.user = dom.editQualityLogForm.elements['edit-quality-user'].value.trim();
        entry.updatedAt = new Date().toISOString();
        const saveFunction = async () => { await dataService.saveWrsData(state.currentWrsData); renderProject(); state.editQualityLogModal.hide(); state.currentlyEditingItem = { index: null, type: null }; };
        try { await saveFunction(); } catch (error) { await handleSaveError(error, saveFunction); }
    };

    const handleEditLogFormSubmit = async (e) => {
        e.preventDefault();
        const { index, type } = state.currentlyEditingItem;
        if (index === null || (type !== 'engineering' && type !== 'support')) return;
        const entry = state.currentWrsData[type][index];
        entry.hours = parseFloat(dom.editLogForm.elements['edit-log-hours'].value);
        entry.partNumber = dom.editLogForm.elements['edit-log-part-number'].value.trim();
        entry.comment = dom.editLogForm.elements['edit-log-comment'].value.trim();
        entry.updatedAt = new Date().toISOString();
        const saveFunction = async () => { await dataService.saveWrsData(state.currentWrsData); renderProject(); state.editLogModal.hide(); state.currentlyEditingItem = { index: null, type: null }; };
        try { await saveFunction(); } catch (error) { await handleSaveError(error, saveFunction); }
    };

    const handleDeleteWrs = async () => {
        if (!state.currentWrsData) return;
        const deleteFunction = async () => {
            try {
                await dataService.deleteWrsData(state.currentWrsData.wrs);
                alert('Proyecto eliminado.');
                state.currentWrsData = null;
                showView(dom.homeView);
            } catch (error) { await handleSaveError(error, deleteFunction); }
        };
        if (confirm(`¿Estás seguro de que quieres eliminar permanentemente el proyecto ${state.currentWrsData.wrs}?`)) await deleteFunction();
    };

    const handleCreateUserFormSubmit = async (e) => {
        e.preventDefault();
        const username = dom.createUserForm.elements['new-username'].value;
        const password = dom.createUserForm.elements['new-password'].value;
        const role = dom.createUserForm.elements['new-role'].value;
        const createUserAction = async () => {
            try {
                dom.createUserError.style.display = 'none';
                await dataService.createUser(username, password, role);
                dom.createUserForm.reset();
                renderUsersTable();
            } catch (error) {
                if (error.status) { dom.createUserError.textContent = error.message; dom.createUserError.style.display = 'block'; } 
                else { alert(error.message); }
            }
        };
        try { await dataService.createUser(username, password, role); dom.createUserForm.reset(); renderUsersTable(); } 
        catch (error) { await handleSaveError(error, () => handleCreateUserFormSubmit(e)); }
    };

    const handleUsersTableClick = async (e) => {
        const target = e.target;
        if (target.classList.contains('delete-user-btn')) {
            const username = target.dataset.username;
            const deleteUserAction = async () => {
                try { await dataService.deleteUser(username); renderUsersTable(); } 
                catch (error) { await handleSaveError(error, deleteUserAction); }
            };
            if (confirm(`¿Seguro que quieres eliminar al usuario ${username}?`)) await deleteUserAction();
        } else if (target.classList.contains('reset-password-btn')) {
            const username = target.dataset.username;
            state.userToResetPassword = username;
            dom.resetPasswordUsername.textContent = username;
            dom.resetPasswordMessage.style.display = 'none';
            dom.resetPasswordForm.reset();
            state.resetPasswordModal.show();
        }
    };

    // --- INITIALIZATION ---
    const init = () => {
        state.loginModal = new bootstrap.Modal(dom.loginModalEl);
        state.registerModal = new bootstrap.Modal(dom.registerModalEl);
        state.changePasswordModal = new bootstrap.Modal(dom.changePasswordModalEl);
        state.resetPasswordModal = new bootstrap.Modal(dom.resetPasswordModalEl);
        state.editItemModal = new bootstrap.Modal(dom.editItemModalEl);
        state.editQualityLogModal = new bootstrap.Modal(dom.editQualityLogModalEl);
        state.editLogModal = new bootstrap.Modal(dom.editLogModalEl);
        state.offcanvasMenu = new bootstrap.Offcanvas(dom.offcanvasMenuEl);

        // Main Navigation
        dom.loginForm.addEventListener('submit', handleLoginFormSubmit);
        dom.registerForm.addEventListener('submit', handleRegisterFormSubmit);
        dom.changePasswordForm.addEventListener('submit', handleChangePasswordFormSubmit);
        dom.resetPasswordForm.addEventListener('submit', handleResetPasswordFormSubmit);
        dom.logoutBtn.addEventListener('click', handleLoginLogoutClick);
        dom.changePasswordBtn.addEventListener('click', () => state.changePasswordModal.show());
        dom.showRegisterModal.addEventListener('click', (e) => {
            e.preventDefault();
            state.loginModal.hide();
            state.registerModal.show();
        });
        dom.showLoginModal.addEventListener('click', (e) => {
            e.preventDefault();
            state.registerModal.hide();
            state.loginModal.show();
        });
        dom.adminViewBtn.addEventListener('click', handleAdminViewClick);
        dom.dashboardLink.addEventListener('click', handleDashboardClick);
        dom.reportLink.addEventListener('click', (e) => { e.preventDefault(); showView(dom.reportView); });
        dom.backToHomeBtn.addEventListener('click', (e) => { e.preventDefault(); showView(dom.projectView); });
        dom.offcanvasWrsForm.addEventListener('submit', handleOffcanvasWrsFormSubmit);

        // Dashboard View
        dom.dashboardHistoryForm.addEventListener('submit', handleDashboardHistoryFormSubmit);
        dom.clearDashboardHistoryFilter.addEventListener('click', () => {
            renderProjectCharts(); // Render with total project data
            dom.dashboardHistoryResultsContainer.style.display = 'none';
            dom.dashboardHistoryForm.reset();
        });
        dom.exportDashboardHistoryBtn.addEventListener('click', () => {
            if (state.dashboardHistoryData) {
                alert('La exportación de historial a Excel aún no está implementada.');
            } else {
                alert('Primero debes buscar datos para poder exportarlos.');
            }
        });

        // Report View
        dom.reportForm.addEventListener('submit', handleReportFormSubmit);
        dom.exportReportBtn.addEventListener('click', () => {
            if (state.technicianReportData) {
                excelService.exportReportToExcel(state.technicianReportData, dom.technicianInput.value.trim());
            }
        });
        dom.reportTableHeader.addEventListener('input', handleReportFilterChange);

        // Home View
        dom.wrsForm.addEventListener('submit', handleWrsFormSubmit);
        dom.importExcelHomeBtn.addEventListener('click', () => dom.importExcelInput.click());
        dom.importExcelInput.addEventListener('change', handleExcelImport);
        dom.recentProjectsList.addEventListener('click', handleRecentProjectClick);

        // Project View
        dom.exportExcelProjectBtn.addEventListener('click', () => excelService.exportWrsToExcel(state.currentWrsData));
        dom.deleteWrsBtn.addEventListener('click', handleDeleteWrs);
        dom.projectTabsContent.addEventListener('submit', (e) => {
            if (e.target.classList.contains('add-item-form')) handleAddItemFormSubmit(e);
            else if (e.target.classList.contains('add-log-form')) handleAddLogSubmit(e);
        });
        dom.projectTabsContent.addEventListener('click', (e) => {
            const target = e.target.closest('.items-table-body, .log-table-body');
            if (target) {
                if (target.classList.contains('items-table-body')) handleItemsTableClick(e);
                else if (target.classList.contains('log-table-body')) handleLogTableClick(e);
            }
        });
        document.getElementById('search-input')?.addEventListener('input', () => { if (state.currentWrsData) renderProject(); });

        // Admin View
        dom.createUserForm.addEventListener('submit', handleCreateUserFormSubmit);
        dom.usersTableBody.addEventListener('click', handleUsersTableClick);

        // Modals
        dom.editItemForm.addEventListener('submit', handleEditItemFormSubmit);
        dom.editQualityLogForm.addEventListener('submit', handleEditQualityLogFormSubmit);
        dom.editLogForm.addEventListener('submit', handleEditLogFormSubmit);

        authService.getUser();
        setupUIForUser();
        showView(dom.homeView);
    };

    init();
});
