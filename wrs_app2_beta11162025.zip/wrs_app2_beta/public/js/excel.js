const excelService = (() => {

    // Helper function to create a styled header cell
    const createHeaderCell = (text) => ({
        v: text,
        t: 's',
        s: {
            font: { bold: true, color: { rgb: "FFFFFFFF" } },
            fill: { fgColor: { rgb: "FF4F81BD" } },
            alignment: { horizontal: "center", vertical: "center" }
        }
    });

    // Function to export the main project data
    const exportWrsToExcel = (wrsData) => {
        if (!wrsData) {
            alert("No hay datos de proyecto para exportar.");
            return;
        }

        const wb = XLSX.utils.book_new();
        const fileName = `WRS_${wrsData.wrs}_Report.xlsx`;

        // Define headers
        const headers = {
            assembly: ["#", "Número de Parte", "Cantidad", "Tiempo Estimado (hrs)", "Tiempo Acumulado (hrs)", "Diferencia (hrs)", "% de Tiempo Utilizado", "Progreso Manual (%)", "Técnico", "Comentario", "Modificado"],
            electrical: ["#", "Número de Parte", "Cantidad", "Tiempo Estimado (hrs)", "Tiempo Acumulado (hrs)", "Diferencia (hrs)", "% de Tiempo Utilizado", "Progreso Manual (%)", "Técnico", "Modificado"],
            engineering: ["#", "Horas", "Número de Parte", "Comentario", "Modificado"],
            support: ["#", "Horas", "Número de Parte", "Comentario", "Modificado"],
            quality: ["#", "Número de Parte", "Estatus", "Comentario", "Usuario", "Modificado"]
        };

        // Process each data type
        Object.keys(headers).forEach(type => {
            const data = wrsData[type] || [];
            if (data.length > 0) {
                const ws_data = [headers[type].map(createHeaderCell)];
                data.forEach((item, index) => {
                    let row = [index + 1];
                    switch(type) {
                        case 'assembly':
                        case 'electrical':
                            const difference = item.estimatedTime - item.accumulatedTime;
                            const timeProgress = item.estimatedTime > 0 ? (item.accumulatedTime / item.estimatedTime) * 100 : 0;
                            row.push(item.number, item.quantity, item.estimatedTime, item.accumulatedTime, difference, `${timeProgress.toFixed(0)}%`, item.manualProgress || 0, item.tecnico || '');
                            if (type === 'assembly') row.push(item.comment || '');
                            row.push(item.updatedAt ? new Date(item.updatedAt).toLocaleString() : 'N/A');
                            break;
                        case 'engineering':
                        case 'support':
                            row.push(item.hours, item.partNumber || 'N/A', item.comment, item.updatedAt ? new Date(item.updatedAt).toLocaleString() : 'N/A');
                            break;
                        case 'quality':
                            row.push(item.partNumber, item.status, item.comment, item.user, item.updatedAt ? new Date(item.updatedAt).toLocaleString() : 'N/A');
                            break;
                    }
                    ws_data.push(row);
                });
                const ws = XLSX.utils.aoa_to_sheet(ws_data);
                XLSX.utils.book_append_sheet(wb, ws, type.charAt(0).toUpperCase() + type.slice(1));
            }
        });

        if (wb.SheetNames.length === 0) {
            alert("No hay datos para exportar en este proyecto.");
            return;
        }

        XLSX.writeFile(wb, fileName);
    };

    // Function to export the technician report data
    const exportReportToExcel = (reportData, techName) => {
        if (!reportData || reportData.length === 0) {
            alert("No hay datos en el reporte para exportar.");
            return;
        }

        const wb = XLSX.utils.book_new();
        const fileName = `Reporte_Tecnico_${techName}.xlsx`;
        const ws_name = "Reporte";

        const headers = ["WRS", "Tipo", "Número de Parte", "Cantidad", "Tiempo Acumulado (hrs)", "Tiempo Restante (hrs)", "Ahorro (%)", "Comentario", "Última Modificación"];
        const ws_data = [headers.map(createHeaderCell)];

        reportData.forEach(item => {
            let row = [
                item.wrs,
                item.type,
                item.partNumber,
                item.quantity || 'N/A',
                item.accumulatedTime || 0,
                item.remainingTime || 0,
                item.savingsPercentage ? item.savingsPercentage.toFixed(2) : 0,
                item.comment || '',
                item.updatedAt ? new Date(item.updatedAt).toLocaleString() : 'N/A'
            ];
            ws_data.push(row);
        });

        const ws = XLSX.utils.aoa_to_sheet(ws_data);
        // Set column widths
        ws['!cols'] = [{wch:10}, {wch:15}, {wch:20}, {wch:10}, {wch:20}, {wch:20}, {wch:15}, {wch:40}, {wch:20}];

        XLSX.utils.book_append_sheet(wb, ws, ws_name);
        XLSX.writeFile(wb, fileName);
    };

    // Function to export the dashboard history data
    const exportHistoryToExcel = (historyData, wrsId, dateRange, totalAverageProgress) => {
        if (!historyData || historyData.length === 0) {
            alert("No hay datos de historial para exportar.");
            return;
        }

        const wb = XLSX.utils.book_new();
        const fileName = `Historial_WRS_${wrsId}_${dateRange.start}_a_${dateRange.end}.xlsx`;
        const ws_name = "Historial";

        // Summary Row
        const summary = [
            { v: "Promedio de Progreso Total del Proyecto:", s: { font: { bold: true } } },
            { v: `${totalAverageProgress}%`, s: { alignment: { horizontal: "right" } } }
        ];

        const headers = ["Tipo", "Número de Parte", "Comentario", "ID Técnico", "Nombre del Técnico", "Progreso de Ensamble (%)", "Horas Agregadas", "Fecha de Modificación", "Fecha de Registro"];
        const ws_data = [summary, [], headers.map(createHeaderCell)]; // Add empty row for spacing

        historyData.forEach(item => {
            const manualProgress = (item.type === 'Ensamble' || item.type === 'Prueba Eléctrica') ? (item.manualProgress || 0) : 'N/A';
            let row = [
                item.type,
                item.partNumber || item.number || 'N/A',
                item.comment || '',
                item.tecnico || '',
                item.tecnicoName || 'N/A',
                manualProgress,
                item.timeAdded || 0,
                item.updatedAt ? new Date(item.updatedAt).toLocaleString() : 'N/A',
                item.snapshotDate ? new Date(item.snapshotDate).toLocaleDateString() : 'N/A'
            ];
            ws_data.push(row);
        });

        const ws = XLSX.utils.aoa_to_sheet(ws_data);
        ws['!cols'] = [{wch:25}, {wch:20}, {wch:40}, {wch:15}, {wch:25}, {wch:25}, {wch:15}, {wch:20}, {wch:20}];
        
        // Merge cells for the summary
        if (!ws['!merges']) ws['!merges'] = [];
        ws['!merges'].push({ s: { r: 0, c: 0 }, e: { r: 0, c: 1 } });


        XLSX.utils.book_append_sheet(wb, ws, ws_name);
        XLSX.writeFile(wb, fileName);
    };


    return {
        exportWrsToExcel,
        exportReportToExcel,
        exportHistoryToExcel
    };

})();