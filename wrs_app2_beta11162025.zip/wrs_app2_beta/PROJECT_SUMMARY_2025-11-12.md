# Resumen del Proyecto: WRS App 2 Beta

**Fecha:** 2025-11-12

## Descripción General

`wrs_app2_beta` es una aplicación web full-stack para la gestión de proyectos, específicamente diseñada para el seguimiento de "Work Request System" (WRS). Permite a los usuarios registrar, seguir y reportar el progreso de diferentes tareas dentro de un proyecto, divididas en categorías como Ensamble, Prueba Eléctrica, Ingeniería, Soporte y Calidad.

La aplicación cuenta con un sistema de autenticación basado en roles (administrador y usuario) y almacena todos sus datos en archivos JSON locales.

## Pila Tecnológica

-   **Backend:** Node.js con Express.js.
-   **Frontend:** HTML, CSS, y JavaScript puro (vanilla JS).
    -   **UI Framework:** Bootstrap 5.
    -   **Gráficos:** Chart.js.
    -   **Exportación a Excel:** SheetJS (xlsx).
-   **Base de Datos:** Sistema de archivos (archivos JSON en el directorio `data`).

## Características Principales

-   **Autenticación de Usuarios:** Sistema de login y registro con roles (`admin`, `user`) usando JWT para la gestión de sesiones.
-   **Gestión de Proyectos (WRS):**
    -   Crear o acceder a proyectos WRS por número.
    -   Agregar, editar y eliminar componentes y entradas de log en 5 categorías.
    -   Seguimiento de tiempos (estimado vs. acumulado) y progreso manual.
-   **Dashboard y Reportes:**
    -   Dashboard visual con gráficos (Doughnut y Barras) que muestran la distribución de horas por categoría.
    -   Historial de actividad del proyecto filtrable por rango de fechas.
    -   Reporte de productividad por técnico.
-   **Gestión de Usuarios (Admin):** Los administradores pueden crear, eliminar y resetear las contraseñas de otros usuarios.
-   **Exportación a Excel:** Funcionalidad para exportar los datos del proyecto, el reporte por técnico y el historial del dashboard a archivos `.xlsx`.

---

## Resumen de Cambios - Sesión del 2025-11-12

Durante esta sesión, se realizaron las siguientes actualizaciones y correcciones:

1.  **Corrección de Bug en Menú:** Se solucionó un error que impedía que el enlace "Dashboard" apareciera en el menú lateral inmediatamente después de iniciar sesión.
2.  **Actualización del Sistema de Autenticación:**
    -   Se migró el identificador de usuario de `username` a `employeeId` (Número de Empleado).
    -   Se añadió un campo `name` (Nombre Personal) al modelo de usuario.
    -   Se actualizaron todos los formularios (login, registro, creación de usuario), tablas y la lógica del frontend y backend para reflejar este cambio.
3.  **Corrección de Inconsistencia de Datos:** Se actualizó el archivo `data/users.json` que contenía formatos de usuario mixtos (antiguos y nuevos), lo que impedía el inicio de sesión.
4.  **Mejoras en el Dashboard:**
    -   La tabla de historial del dashboard ahora muestra columnas separadas para "ID Técnico" y "Nombre del Técnico".
    -   Se añadió la columna "Progreso de Ensamble (%)" a la tabla de historial.
    -   Se implementó el cálculo del **promedio de progreso de todo el proyecto**, que ahora se muestra en el dashboard.
5.  **Implementación de Exportación a Excel para el Historial:**
    -   Se activó el botón "Exportar a Excel" en la vista de historial del dashboard.
    -   La función de exportación ahora genera un archivo `.xlsx` que incluye todos los datos filtrados y una fila de resumen con el promedio de progreso total del proyecto.
6.  **Ajuste en la Visualización de Datos:**
    -   La columna "Técnico" en la vista principal del proyecto ahora muestra el `employeeId` del usuario.
    -   El saludo en el menú lateral (`Usuario: ...`) ahora muestra el `name` del usuario.
