const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cron = require('node-cron');

const app = express();
const PORT = 3000;
const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const JWT_SECRET = 'your-super-secret-key'; // TODO: Debería estar en una variable de entorno

// --- Middleware ---
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) return res.sendStatus(401); // No hay token

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403); // Token inválido
        req.user = user;
        next();
    });
};

const isAdmin = (req, res, next) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Acceso denegado. Se requiere rol de administrador.' });
    }
    next();
};

// --- Rutas de Autenticación ---

app.post('/api/login', async (req, res) => {
    const { employeeId, password } = req.body;
    if (!employeeId || !password) {
        return res.status(400).json({ message: 'Número de empleado y contraseña son requeridos.' });
    }

    try {
        const usersData = await fs.readFile(USERS_FILE, 'utf-8');
        const users = JSON.parse(usersData);
        const user = users.find(u => u.employeeId === employeeId);

        if (!user) {
            return res.status(400).json({ message: 'Empleado o contraseña incorrectos.' });
        }

        if (await bcrypt.compare(password, user.password)) {
            // Contraseña correcta, crear JWT
            const accessToken = jwt.sign({ employeeId: user.employeeId, role: user.role, name: user.name }, JWT_SECRET, { expiresIn: '1h' });
            res.json({ accessToken: accessToken, user: { employeeId: user.employeeId, role: user.role, name: user.name } });
        } else {
            res.status(400).json({ message: 'Empleado o contraseña incorrectos.' });
        }
    } catch (error) {
        console.error('Error en el login:', error);
        res.status(500).json({ message: 'Error interno del servidor.' });
    }
});

app.post('/api/register', async (req, res) => {
    const { employeeId, password, name } = req.body;
    if (!employeeId || !password || !name) {
        return res.status(400).json({ message: 'Número de empleado, nombre y contraseña son requeridos.' });
    }

    try {
        let users = [];
        try {
            const usersData = await fs.readFile(USERS_FILE, 'utf-8');
            users = JSON.parse(usersData);
        } catch (readError) {
            if (readError.code !== 'ENOENT') {
                throw readError;
            }
            // El archivo no existe, se creará.
        }

        if (users.find(u => u.employeeId === employeeId)) {
            return res.status(409).json({ message: 'El número de empleado ya existe.' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        // Los usuarios que se registran por sí mismos tienen el rol 'user' por defecto
        users.push({ employeeId, name, password: hashedPassword, role: 'user' });

        await fs.mkdir(DATA_DIR, { recursive: true });
        await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
        res.status(201).json({ message: 'Usuario creado con éxito. Ahora puedes iniciar sesión.' });

    } catch (error) {
        console.error('Error al registrar el usuario:', error);
        res.status(500).json({ message: 'Error interno del servidor.' });
    }
});

// --- API Endpoints para WRS (Proyectos) ---

const countItems = (data) => {
    if (!data) return 0;
    let count = 0;
    if (data.assembly) count += data.assembly.length;
    if (data.electrical) count += data.electrical.length;
    if (data.engineering) count += data.engineering.length;
    if (data.support) count += data.support.length;
    if (data.quality) count += data.quality.length;
    return count;
};

const HISTORY_DIR = path.join(DATA_DIR, 'history');

const updateHistory = async (wrsId, changedItem, itemType, timeAdded) => {
    // Note: timeAdded can be negative if time was manually removed.

    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const todayDateString = `${year}-${month}-${day}`;
    const projectHistoryDir = path.join(HISTORY_DIR, wrsId);
    await fs.mkdir(projectHistoryDir, { recursive: true });
    const historyFilePath = path.join(projectHistoryDir, `${todayDateString}.json`);

    let dailyHistory = [];
    try {
        const content = await fs.readFile(historyFilePath, 'utf-8');
        dailyHistory = JSON.parse(content);
    } catch (e) {
        if (e.code !== 'ENOENT') {
            console.error(`Error reading or parsing history file ${historyFilePath}:`, e);
            throw new Error(`El archivo de historial para el día de hoy está corrupto. Por favor, corrígelo o elimínalo: ${todayDateString}.json`);
        }
        // If ENOENT, proceed with empty dailyHistory array.
    }

    const existingEntryIndex = dailyHistory.findIndex(entry => entry.uuid === changedItem.uuid);

    if (existingEntryIndex > -1) {
        // Update existing entry for today
        dailyHistory[existingEntryIndex].timeAdded += timeAdded;
        // Also update the main properties from the changed item
        if (changedItem.accumulatedTime !== undefined) dailyHistory[existingEntryIndex].accumulatedTime = changedItem.accumulatedTime;
        if (changedItem.hours !== undefined) dailyHistory[existingEntryIndex].hours = changedItem.hours;
        dailyHistory[existingEntryIndex].manualProgress = changedItem.manualProgress;
        dailyHistory[existingEntryIndex].tecnico = changedItem.tecnico;
        dailyHistory[existingEntryIndex].comment = changedItem.comment;
        dailyHistory[existingEntryIndex].updatedAt = new Date().toISOString();
    } else {
        // Add new entry for today
        dailyHistory.push({
            ...changedItem,
            wrs: wrsId,
            type: itemType,
            timeAdded: timeAdded,
            snapshotDate: todayDateString
        });
    }

    await fs.writeFile(historyFilePath, JSON.stringify(dailyHistory, null, 2), 'utf-8');
    console.log(`History updated for WRS ${wrsId}, item ${changedItem.uuid || changedItem.number}. Change: ${timeAdded} hours.`);
};

const removeFromHistory = async (wrsId, deletedItemUuid) => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const todayDateString = `${year}-${month}-${day}`;
    const historyFilePath = path.join(HISTORY_DIR, wrsId, `${todayDateString}.json`);

    let dailyHistory = [];
    try {
        const content = await fs.readFile(historyFilePath, 'utf-8');
        dailyHistory = JSON.parse(content);
    } catch (e) {
        // If the history file doesn't exist, there's nothing to remove.
        return;
    }

    const newDailyHistory = dailyHistory.filter(entry => entry.uuid !== deletedItemUuid);

    // Only write the file back if something was actually removed.
    if (newDailyHistory.length < dailyHistory.length) {
        await fs.writeFile(historyFilePath, JSON.stringify(newDailyHistory, null, 2), 'utf-8');
        console.log(`Removed item ${deletedItemUuid} from daily history for WRS ${wrsId}.`);
    }
};


app.get('/api/wrs/:id', async (req, res) => {
    const wrsId = req.params.id;
    const filePath = path.join(DATA_DIR, `${wrsId}.json`);

    try {
        const data = await fs.readFile(filePath, 'utf-8');
        res.json(JSON.parse(data));
    } catch (error) {
        if (error.code === 'ENOENT') {
            // Si el proyecto no existe, se crea uno nuevo con versión 0
            res.json({
                wrs: wrsId,
                version: 0,
                assembly: [],
                electrical: [],
                engineering: [],
                support: [],
                quality: [],
            });
        } else {
            console.error('Error al leer el archivo del proyecto:', error);
            res.status(500).json({ message: 'Error interno al leer el proyecto' });
        }
    }
});

app.post('/api/wrs/:id', async (req, res) => {
    const wrsId = req.params.id;
    const filePath = path.join(DATA_DIR, `${wrsId}.json`);
    const incomingData = req.body;

    try {
        let existingData = { version: 0, assembly: [], electrical: [], engineering: [], support: [] };
        try {
            const existingFileContent = await fs.readFile(filePath, 'utf-8');
            existingData = JSON.parse(existingFileContent);
        } catch (readError) {
            if (readError.code !== 'ENOENT') throw readError;
        }

        const currentVersion = existingData.version || 0;
        if (incomingData.version !== currentVersion) {
            return res.status(409).json({ 
                message: 'Conflicto de versiones. Alguien más ha guardado cambios en este proyecto. Por favor, recarga la página.' 
            });
        }

        // --- History Update Logic ---
        for (const type of ['assembly', 'electrical', 'engineering', 'support']) {
            const oldItems = new Map((existingData[type] || []).map(item => [item.uuid, item]));
            const newItems = new Map((incomingData[type] || []).map(item => [item.uuid, item]));
            const itemTypeString = {
                assembly: 'Ensamble',
                electrical: 'Prueba Eléctrica',
                engineering: 'Ingeniería',
                support: 'Soporte'
            }[type];

            if (!itemTypeString) continue;

            // Handle Updates and Additions
            for (const [uuid, newItem] of newItems.entries()) {
                const oldItem = oldItems.get(uuid);
                let timeAdded = 0;
                const isTimeTracked = type === 'assembly' || type === 'electrical';
                const isLogTracked = type === 'engineering' || type === 'support';

                if (oldItem) { // Item existed, calculate delta
                    const oldTime = isTimeTracked ? oldItem.accumulatedTime : (isLogTracked ? oldItem.hours : 0);
                    const newTime = isTimeTracked ? newItem.accumulatedTime : (isLogTracked ? newItem.hours : 0);
                    timeAdded = (newTime || 0) - (oldTime || 0);
                } else { // New item, all its time is "added"
                    timeAdded = isTimeTracked ? newItem.accumulatedTime : (isLogTracked ? newItem.hours : 0);
                    timeAdded = timeAdded || 0;
                }

                if (timeAdded !== 0) {
                    await updateHistory(wrsId, newItem, itemTypeString, timeAdded);
                }
            }

            // Handle Deletions
            for (const [uuid, oldItem] of oldItems.entries()) {
                if (!newItems.has(uuid)) {
                    // This item was deleted
                    await removeFromHistory(wrsId, uuid);
                }
            }
        }
        // --- End of History Update Logic ---

        const isDeletion = countItems(incomingData) < countItems(existingData);
        if (isDeletion) {
            const authHeader = req.headers['authorization'];
            const token = authHeader && authHeader.split(' ')[1];
            if (token == null) return res.status(401).json({ message: 'Se requiere autenticación de administrador para eliminar.' });
            let user;
            try { user = jwt.verify(token, JWT_SECRET); } catch (err) { return res.status(403).json({ message: 'Token inválido o expirado.' }); }
            if (user.role !== 'admin') return res.status(403).json({ message: 'Se requieren permisos de administrador para eliminar.' });
        }

        // Preserve assignedAdmins if they are not in the incoming data
        if (!incomingData.assignedAdmins && existingData.assignedAdmins) {
            incomingData.assignedAdmins = existingData.assignedAdmins;
        }

        // Save the main WRS file
        incomingData.version = currentVersion + 1;
        await fs.mkdir(DATA_DIR, { recursive: true });
        await fs.writeFile(filePath, JSON.stringify(incomingData, null, 2), 'utf-8');
        res.status(200).json({ message: 'Proyecto guardado con éxito', newVersion: incomingData.version });

    } catch (error) {
        console.error(`Error al guardar el proyecto ${wrsId}:`, error);
        res.status(500).json({ message: 'Error interno al guardar el proyecto' });
    }
});

app.post('/api/wrs/:id/assign', authenticateToken, isAdmin, async (req, res) => {
    const wrsId = req.params.id;
    const filePath = path.join(DATA_DIR, `${wrsId}.json`);
    const { primary, secondary, tertiary } = req.body;

    try {
        let projectData;
        try {
            const fileContent = await fs.readFile(filePath, 'utf-8');
            projectData = JSON.parse(fileContent);
        } catch (readError) {
            if (readError.code === 'ENOENT') {
                return res.status(404).json({ message: 'Proyecto no encontrado.' });
            }
            throw readError;
        }

        projectData.assignedAdmins = {
            primary: primary || null,
            secondary: secondary || null,
            tertiary: tertiary || null
        };

        await fs.writeFile(filePath, JSON.stringify(projectData, null, 2), 'utf-8');
        res.status(200).json({ message: 'Administradores asignados con éxito.' });

    } catch (error) {
        console.error(`Error al asignar administradores para el proyecto ${wrsId}:`, error);
        res.status(500).json({ message: 'Error interno al asignar administradores.' });
    }
});

app.delete('/api/wrs/:id', authenticateToken, isAdmin, async (req, res) => {
    const wrsId = req.params.id;
    const filePath = path.join(DATA_DIR, `${wrsId}.json`);

    try {
        await fs.unlink(filePath);
        res.status(200).json({ message: 'Proyecto eliminado con éxito.' });
    } catch (error) {
        if (error.code === 'ENOENT') {
            return res.status(404).json({ message: 'Proyecto no encontrado.' });
        }
        console.error(`Error al eliminar el proyecto ${wrsId}:`, error);
        res.status(500).json({ message: 'Error interno al eliminar el proyecto.' });
    }
});

// --- Admin Dashboard Endpoint ---
app.get('/api/projects/summary', authenticateToken, async (req, res) => {
    try {
        const adminId = req.user.employeeId;
        const files = await fs.readdir(DATA_DIR);
        const projectFiles = files.filter(file => file.endsWith('.json') && file !== 'users.json');
        
        const assignedProjects = [];

        for (const file of projectFiles) {
            const filePath = path.join(DATA_DIR, file);
            const fileContent = await fs.readFile(filePath, 'utf-8');
            const projectData = JSON.parse(fileContent);

            const assignments = projectData.assignedAdmins;
            if (assignments && (assignments.primary === adminId || assignments.secondary === adminId || assignments.tertiary === adminId)) {
                assignedProjects.push({
                    wrs: projectData.wrs,
                    assembly: projectData.assembly || []
                });
            }
        }

        res.json(assignedProjects);

    } catch (error) {
        console.error('Error generating projects summary:', error);
        res.status(500).json({ message: 'Error interno al generar el resumen de proyectos.' });
    }
});



// --- API Endpoints para Gestión de Usuarios (Solo Admins) ---

app.get('/api/users', authenticateToken, isAdmin, async (req, res) => {
    try {
        const usersData = await fs.readFile(USERS_FILE, 'utf-8');
        const users = JSON.parse(usersData);
        // No enviar las contraseñas al cliente
        const usersWithoutPasswords = users.map(({ password, ...user }) => user);
        res.json(usersWithoutPasswords);
    } catch (error) {
        console.error('Error al leer el archivo de usuarios:', error);
        res.status(500).json({ message: 'Error interno del servidor.' });
    }
});

app.post('/api/users', authenticateToken, isAdmin, async (req, res) => {
    const { employeeId, password, role, name } = req.body;
    if (!employeeId || !password || !role || !name) {
        return res.status(400).json({ message: 'Número de empleado, nombre, contraseña y rol son requeridos.' });
    }
    if (role !== 'admin' && role !== 'user') {
        return res.status(400).json({ message: 'El rol debe ser "admin" o "user".' });
    }

    try {
        const usersData = await fs.readFile(USERS_FILE, 'utf-8');
        const users = JSON.parse(usersData);

        if (users.find(u => u.employeeId === employeeId)) {
            return res.status(409).json({ message: 'El número de empleado ya existe.' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        users.push({ employeeId, name, password: hashedPassword, role });

        await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
        res.status(201).json({ message: 'Usuario creado con éxito.' });

    } catch (error) {
        console.error('Error al crear el usuario:', error);
        res.status(500).json({ message: 'Error interno del servidor.' });
    }
});

app.delete('/api/users/:employeeId', authenticateToken, isAdmin, async (req, res) => {
    const targetEmployeeId = req.params.employeeId;

    if (req.user.employeeId === targetEmployeeId) {
        return res.status(400).json({ message: 'No puedes eliminarte a ti mismo.' });
    }

    try {
        const usersData = await fs.readFile(USERS_FILE, 'utf-8');
        let users = JSON.parse(usersData);
        const initialLength = users.length;

        users = users.filter(u => u.employeeId !== targetEmployeeId);

        if (users.length === initialLength) {
            return res.status(404).json({ message: 'Usuario no encontrado.' });
        }

        await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
        res.status(200).json({ message: 'Usuario eliminado con éxito.' });

    } catch (error) {
        console.error('Error al eliminar el usuario:', error);
        res.status(500).json({ message: 'Error interno del servidor.' });
    }
});

app.post('/api/user/password', authenticateToken, async (req, res) => {
    const { currentPassword, newPassword } = req.body;
    const employeeId = req.user.employeeId;

    if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: 'La contraseña actual y la nueva son requeridas.' });
    }

    try {
        const usersData = await fs.readFile(USERS_FILE, 'utf-8');
        let users = JSON.parse(usersData);
        const user = users.find(u => u.employeeId === employeeId);

        if (!user) {
            return res.status(404).json({ message: 'Usuario no encontrado.' });
        }

        if (await bcrypt.compare(currentPassword, user.password)) {
            const hashedNewPassword = await bcrypt.hash(newPassword, 10);
            user.password = hashedNewPassword;
            await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
            res.status(200).json({ message: 'Contraseña actualizada con éxito.' });
        } else {
            res.status(400).json({ message: 'La contraseña actual es incorrecta.' });
        }
    } catch (error) {
        console.error('Error al cambiar la contraseña:', error);
        res.status(500).json({ message: 'Error interno del servidor.' });
    }
});

app.post('/api/users/:employeeId/reset-password', authenticateToken, isAdmin, async (req, res) => {
    const { newPassword } = req.body;
    const targetEmployeeId = req.params.employeeId;

    if (!newPassword) {
        return res.status(400).json({ message: 'La nueva contraseña es requerida.' });
    }

    try {
        const usersData = await fs.readFile(USERS_FILE, 'utf-8');
        let users = JSON.parse(usersData);
        const user = users.find(u => u.employeeId === targetEmployeeId);

        if (!user) {
            return res.status(404).json({ message: 'Usuario no encontrado.' });
        }

        const hashedNewPassword = await bcrypt.hash(newPassword, 10);
        user.password = hashedNewPassword;

        await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
        res.status(200).json({ message: `Contraseña para ${targetEmployeeId} ha sido reseteada con éxito.` });

    } catch (error) {
        console.error(`Error al resetear la contraseña para ${targetEmployeeId}:`, error);
        res.status(500).json({ message: 'Error interno del servidor.' });
    }
});

// --- API Endpoint for History ---

app.get('/api/history/:id', authenticateToken, async (req, res) => {
    const wrsId = req.params.id;
    const { startDate, endDate } = req.query;

    if (!startDate || !endDate) {
        return res.status(400).json({ message: 'Los parámetros startDate y endDate son requeridos.' });
    }

    try {
        const start = new Date(startDate);
        start.setUTCHours(0, 0, 0, 0);
        const end = new Date(endDate);
        end.setUTCHours(23, 59, 59, 999);

        // Leer usuarios para mapear ID a nombre
        let userMap = {};
        try {
            const usersData = await fs.readFile(USERS_FILE, 'utf-8');
            const users = JSON.parse(usersData);
            users.forEach(u => { userMap[u.employeeId] = u.name; });
        } catch (userError) {
            console.error("No se pudo leer el archivo de usuarios, los nombres no se incluirán en el historial.", userError);
        }

        const projectHistoryDir = path.join(HISTORY_DIR, wrsId);
        const modificationsInRange = [];
        let totalHoursInRange = 0;

        try {
            await fs.access(projectHistoryDir);
            const historyFiles = await fs.readdir(projectHistoryDir);

            for (const file of historyFiles) {
                const fileDateStr = path.basename(file, '.json');
                const fileDate = new Date(fileDateStr);
                fileDate.setUTCHours(12, 0, 0, 0);

                if (fileDate >= start && fileDate <= end) {
                    const filePath = path.join(projectHistoryDir, file);
                    const dailyItems = JSON.parse(await fs.readFile(filePath, 'utf-8'));
                    
                    for (const item of dailyItems) {
                        totalHoursInRange += item.timeAdded || 0;
                        // Adjuntar el nombre del técnico
                        item.tecnicoName = userMap[item.tecnico] || 'N/A';
                        modificationsInRange.push(item);
                    }
                }
            }
        } catch (histError) {
            if (histError.code !== 'ENOENT') throw histError;
            // No history directory, so totals are 0 and modifications are empty.
        }

        modificationsInRange.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));

        res.json({
            modifications: modificationsInRange,
            summary: {
                totalHoursInRange: totalHoursInRange,
            }
        });

    } catch (error) {
        console.error(`Error fetching history for ${wrsId}:`, error);
        res.status(500).json({ message: 'Error interno al obtener el historial.' });
    }
});


// --- Iniciar el servidor ---
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
    console.log(`Accesible en tu red local (LAN). Para encontrar tu IP, abre un terminal y ejecuta: ipconfig`);
});

// --- Inicialización de usuarios ---
async function initializeUsers() {
    try {
        await fs.access(USERS_FILE);
    } catch (error) {
        // El archivo no existe, crearlo con un usuario admin por defecto
        if (error.code === 'ENOENT') {
            console.log('Archivo de usuarios no encontrado. Creando uno nuevo con un administrador por defecto.');
            try {
                const defaultAdminPassword = 'admin'; // Cambiar esto en un entorno de producción
                const hashedPassword = await bcrypt.hash(defaultAdminPassword, 10);
                const defaultUsers = [{
                    employeeId: 'admin',
                    name: 'Admin',
                    password: hashedPassword,
                    role: 'admin'
                }];
                await fs.mkdir(DATA_DIR, { recursive: true });
                await fs.writeFile(USERS_FILE, JSON.stringify(defaultUsers, null, 2), 'utf-8');
                console.log(`Usuario por defecto 'admin' con contraseña '${defaultAdminPassword}' creado.`);
            } catch (initError) {
                console.error('Error al inicializar el archivo de usuarios:', initError);
            }
        }
    }
}

initializeUsers();


app.use((req, res, next) => {
  if (req.method === 'GET' && !req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  } else {
    next();
  }
});